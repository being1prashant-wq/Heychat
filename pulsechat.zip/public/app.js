(function () {
  'use strict';

  // ========== STATE ==========
  const state = {
    screen: 'welcome',
    user: null,
    sessionToken: localStorage.getItem('pc_session') || null,
    interests: JSON.parse(localStorage.getItem('pc_interests') || '[]'),
    displayName: localStorage.getItem('pc_name') || '',
    gender: localStorage.getItem('pc_gender') || 'prefer-not',
    matchWithInterests: true,
    acceptedTerms: false,
    ageConfirmed: false,
    chat: null,
    partner: null,
    messages: [],
    isTyping: false,
    searching: false,
    socket: null,
    connected: false
  };

  const SUGGESTED = [
    'Gaming', 'Music', 'Cricket', 'Movies', 'Coding',
    'Punjabi', 'Travel', 'Sports', 'Anime', 'Food',
    'Photography', 'Fitness', 'Books', 'Tech', 'Art'
  ];

  // ========== DOM ==========
  const app = document.getElementById('app');

  function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstChild;
  }

  function toast(msg, ms = 2800) {
    let t = document.querySelector('.toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), ms);
  }

  // ========== SOCKET ==========
  function connectSocket() {
    if (state.socket) return;
    const socket = io({
      auth: { token: state.sessionToken },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 12,
      reconnectionDelay: 1000
    });

    state.socket = socket;

    socket.on('connect', () => {
      state.connected = true;
      console.log('Connected', socket.id);
      // Re-register if we have session
      if (state.user || state.sessionToken) {
        registerUser();
      }
    });

    socket.on('disconnect', () => {
      state.connected = false;
      if (state.searching) {
        // Will auto rejoin on reconnect via register
      }
    });

    socket.on('match_found', (data) => {
      state.searching = false;
      state.chat = { id: data.chatId };
      state.partner = data.partner;
      state.messages = [];
      showScreen('chat');
      toast('Match found!');
    });

    socket.on('chat_message', (msg) => {
      state.messages.push(msg);
      if (state.screen === 'chat') {
        appendMessage(msg);
        scrollMessages();
      }
    });

    socket.on('typing_start', () => {
      const ind = document.getElementById('typingInd');
      if (ind) ind.classList.add('show');
    });

    socket.on('typing_stop', () => {
      const ind = document.getElementById('typingInd');
      if (ind) ind.classList.remove('show');
    });

    socket.on('chat_end', (data) => {
      const reason = data?.reason || 'left';
      if (state.screen === 'chat') {
        toast(reason === 'next' ? 'Partner found someone new' : 'Partner left the chat');
        state.chat = null;
        state.partner = null;
        state.messages = [];
        showScreen('setup');
      }
    });

    socket.on('connect_error', (err) => {
      console.warn('Socket error', err.message);
    });
  }

  function registerUser(cb) {
    if (!state.socket || !state.socket.connected) {
      connectSocket();
      setTimeout(() => registerUser(cb), 400);
      return;
    }
    state.socket.emit('register', {
      displayName: state.displayName || 'Anonymous',
      interests: state.interests,
      gender: state.gender,
      sessionToken: state.sessionToken
    }, (res) => {
      if (res?.error) {
        toast(res.error);
        return cb?.(false);
      }
      if (res?.user) {
        state.user = res.user;
        state.sessionToken = res.user.sessionToken;
        state.displayName = res.user.displayName;
        state.interests = res.user.interests || [];
        localStorage.setItem('pc_session', state.sessionToken);
        localStorage.setItem('pc_name', state.displayName);
        localStorage.setItem('pc_interests', JSON.stringify(state.interests));
        localStorage.setItem('pc_gender', state.gender);
      }
      cb?.(true);
    });
  }

  // ========== SCREENS ==========
  function showScreen(name) {
    state.screen = name;
    render();
  }

  function render() {
    app.innerHTML = '';
    if (state.screen === 'welcome') app.appendChild(renderWelcome());
    else if (state.screen === 'age') app.appendChild(renderAge());
    else if (state.screen === 'name') app.appendChild(renderName());
    else if (state.screen === 'gender') app.appendChild(renderGender());
    else if (state.screen === 'interests') app.appendChild(renderInterests());
    else if (state.screen === 'setup') app.appendChild(renderSetup());
    else if (state.screen === 'searching') app.appendChild(renderSearching());
    else if (state.screen === 'chat') app.appendChild(renderChat());
  }

  // ----- Welcome -----
  function renderWelcome() {
    const s = el(`<div class="screen active"></div>`);
    s.innerHTML = `
      <div style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <div class="logo">Pulse<span>Chat</span></div>
        <p class="tagline">Talk to random people who share your interests. Anonymous, fast, and simple.</p>
      </div>
      <button class="btn btn-primary" id="startBtn">Continue</button>
      <p style="text-align:center;margin-top:16px;font-size:12px;color:#666;">By continuing you agree to our Terms & Privacy Policy</p>
    `;
    s.querySelector('#startBtn').onclick = () => showScreen('age');
    return s;
  }

  // ----- Age / Safety -----
  function renderAge() {
    const s = el(`<div class="screen active"></div>`);
    s.innerHTML = `
      <div class="section-title">Before you start</div>
      <p class="section-desc">PulseChat is for users 18 years and older. Please confirm you meet the age requirement and will follow community guidelines.</p>
      <div class="checkbox-row">
        <input type="checkbox" id="ageCheck" ${state.ageConfirmed ? 'checked' : ''} />
        <label for="ageCheck">I confirm I am 18 years of age or older</label>
      </div>
      <div class="checkbox-row">
        <input type="checkbox" id="termsCheck" ${state.acceptedTerms ? 'checked' : ''} />
        <label for="termsCheck">I accept the Terms of Service and Privacy Policy. I will not share personal information, engage in harassment, or use this platform for illegal activity.</label>
      </div>
      <div style="flex:1"></div>
      <button class="btn btn-primary" id="ageContinue" disabled>Continue</button>
      <button class="btn btn-ghost" style="margin-top:10px" id="ageBack">Back</button>
    `;
    const age = s.querySelector('#ageCheck');
    const terms = s.querySelector('#termsCheck');
    const btn = s.querySelector('#ageContinue');
    function update() {
      state.ageConfirmed = age.checked;
      state.acceptedTerms = terms.checked;
      btn.disabled = !(age.checked && terms.checked);
    }
    age.onchange = update;
    terms.onchange = update;
    update();
    btn.onclick = () => showScreen('name');
    s.querySelector('#ageBack').onclick = () => showScreen('welcome');
    return s;
  }

  // ----- Name -----
  function renderName() {
    const s = el(`<div class="screen active"></div>`);
    s.innerHTML = `
      <div class="section-title">Choose a display name</div>
      <p class="section-desc">This is how others will see you. You can change it later.</p>
      <label class="label">Display name</label>
      <input class="input" id="nameInput" maxlength="24" placeholder="e.g. Alex" value="${escapeHtml(state.displayName)}" />
      <div style="flex:1"></div>
      <button class="btn btn-primary" id="nameContinue">Continue</button>
      <button class="btn btn-ghost" style="margin-top:10px" id="nameBack">Back</button>
    `;
    const input = s.querySelector('#nameInput');
    s.querySelector('#nameContinue').onclick = () => {
      const v = input.value.trim().slice(0, 24) || 'Anonymous';
      state.displayName = v;
      localStorage.setItem('pc_name', v);
      showScreen('gender');
    };
    s.querySelector('#nameBack').onclick = () => showScreen('age');
    input.focus();
    return s;
  }

  // ----- Gender -----
  function renderGender() {
    const s = el(`<div class="screen active"></div>`);
    const options = [
      { id: 'male', label: 'Male' },
      { id: 'female', label: 'Female' },
      { id: 'other', label: 'Other' },
      { id: 'prefer-not', label: 'Prefer not to say' }
    ];
    s.innerHTML = `
      <div class="section-title">Gender (optional)</div>
      <p class="section-desc">Helps with better matching. Completely optional.</p>
      <div class="gender-grid" id="genderGrid"></div>
      <div style="flex:1"></div>
      <button class="btn btn-primary" id="genderContinue">Continue</button>
      <button class="btn btn-ghost" style="margin-top:10px" id="genderBack">Back</button>
    `;
    const grid = s.querySelector('#genderGrid');
    options.forEach(o => {
      const b = document.createElement('button');
      b.className = 'gender-btn' + (state.gender === o.id ? ' selected' : '');
      b.textContent = o.label;
      b.onclick = () => {
        state.gender = o.id;
        localStorage.setItem('pc_gender', o.id);
        grid.querySelectorAll('.gender-btn').forEach(x => x.classList.remove('selected'));
        b.classList.add('selected');
      };
      grid.appendChild(b);
    });
    s.querySelector('#genderContinue').onclick = () => showScreen('interests');
    s.querySelector('#genderBack').onclick = () => showScreen('name');
    return s;
  }

  // ----- Interests -----
  function renderInterests() {
    const s = el(`<div class="screen active"></div>`);
    s.innerHTML = `
      <div class="section-title">Your interests</div>
      <p class="section-desc">Optional. Add a few to find people with similar vibes. You can skip or edit anytime.</p>
      <div class="chips" id="myChips"></div>
      <div class="add-interest">
        <input class="input" id="interestInput" placeholder="Add an interest..." maxlength="24" />
        <button class="btn btn-primary" style="width:auto;padding:12px 18px;min-height:auto" id="addInterest">Add</button>
      </div>
      <p class="label" style="margin-top:20px">Suggestions</p>
      <div class="chips" id="suggestChips"></div>
      <div style="flex:1"></div>
      <button class="btn btn-primary" id="intContinue">Continue</button>
      <button class="btn btn-ghost" style="margin-top:10px" id="intBack">Back</button>
    `;
    const myChips = s.querySelector('#myChips');
    const suggest = s.querySelector('#suggestChips');
    const input = s.querySelector('#interestInput');

    function refreshChips() {
      myChips.innerHTML = '';
      state.interests.forEach((i, idx) => {
        const c = document.createElement('span');
        c.className = 'chip';
        c.innerHTML = `${escapeHtml(i)} <span class="remove" data-i="${idx}">×</span>`;
        c.querySelector('.remove').onclick = () => {
          state.interests.splice(idx, 1);
          localStorage.setItem('pc_interests', JSON.stringify(state.interests));
          refreshChips();
        };
        myChips.appendChild(c);
      });
      suggest.innerHTML = '';
      SUGGESTED.filter(x => !state.interests.map(y => y.toLowerCase()).includes(x.toLowerCase())).forEach(x => {
        const c = document.createElement('button');
        c.className = 'chip chip-suggest';
        c.textContent = x;
        c.onclick = () => {
          if (state.interests.length >= 12) return toast('Max 12 interests');
          state.interests.push(x);
          localStorage.setItem('pc_interests', JSON.stringify(state.interests));
          refreshChips();
        };
        suggest.appendChild(c);
      });
    }
    refreshChips();

    function addCurrent() {
      const v = input.value.trim();
      if (!v) return;
      if (state.interests.length >= 12) return toast('Max 12 interests');
      if (state.interests.map(x => x.toLowerCase()).includes(v.toLowerCase())) {
        input.value = '';
        return;
      }
      state.interests.push(v);
      localStorage.setItem('pc_interests', JSON.stringify(state.interests));
      input.value = '';
      refreshChips();
    }
    s.querySelector('#addInterest').onclick = addCurrent;
    input.onkeydown = (e) => { if (e.key === 'Enter') addCurrent(); };

    s.querySelector('#intContinue').onclick = () => {
      registerUser(() => showScreen('setup'));
    };
    s.querySelector('#intBack').onclick = () => showScreen('gender');
    return s;
  }

  // ----- New Chat Setup -----
  function renderSetup() {
    const s = el(`<div class="screen active"></div>`);
    s.innerHTML = `
      <div class="section-title">New Chat</div>
      <p class="section-desc">Find someone to talk to. Interests help us match you better.</p>

      <div class="card">
        <div class="toggle-row">
          <span style="font-weight:500">Match with interests</span>
          <div class="toggle ${state.matchWithInterests ? 'on' : ''}" id="matchToggle"></div>
        </div>
        <div class="chips" id="setupChips" style="margin-top:12px"></div>
        <div class="add-interest">
          <input class="input" id="setupInterest" placeholder="Add an interest..." maxlength="24" />
          <button class="btn btn-ghost" style="width:auto;padding:12px 16px;min-height:auto;border-radius:10px" id="setupAdd">Add</button>
        </div>
      </div>

      <div style="flex:1"></div>
      <button class="btn btn-primary" id="startChat">Start Chat</button>
      <button class="btn btn-ghost" style="margin-top:10px" id="editProfile">Edit profile</button>
    `;

    const chips = s.querySelector('#setupChips');
    function refresh() {
      chips.innerHTML = '';
      state.interests.forEach((i, idx) => {
        const c = document.createElement('span');
        c.className = 'chip';
        c.innerHTML = `${escapeHtml(i)} <span class="remove" data-i="${idx}">×</span>`;
        c.querySelector('.remove').onclick = () => {
          state.interests.splice(idx, 1);
          localStorage.setItem('pc_interests', JSON.stringify(state.interests));
          refresh();
          updateProfile();
        };
        chips.appendChild(c);
      });
    }
    refresh();

    s.querySelector('#matchToggle').onclick = function () {
      state.matchWithInterests = !state.matchWithInterests;
      this.classList.toggle('on', state.matchWithInterests);
    };

    const input = s.querySelector('#setupInterest');
    s.querySelector('#setupAdd').onclick = () => {
      const v = input.value.trim();
      if (!v || state.interests.length >= 12) return;
      if (state.interests.map(x => x.toLowerCase()).includes(v.toLowerCase())) return;
      state.interests.push(v);
      localStorage.setItem('pc_interests', JSON.stringify(state.interests));
      input.value = '';
      refresh();
      updateProfile();
    };

    s.querySelector('#startChat').onclick = () => {
      if (!state.socket?.connected) {
        toast('Connecting...');
        connectSocket();
        setTimeout(() => startSearch(), 600);
        return;
      }
      startSearch();
    };

    s.querySelector('#editProfile').onclick = () => showScreen('interests');
    return s;
  }

  function updateProfile() {
    if (state.socket?.connected) {
      state.socket.emit('update_profile', {
        displayName: state.displayName,
        interests: state.interests,
        gender: state.gender
      });
    }
  }

  function startSearch() {
    state.searching = true;
    showScreen('searching');
    state.socket.emit('queue_join', {
      interests: state.interests,
      matchWithInterests: state.matchWithInterests
    }, (res) => {
      if (res?.error) {
        toast(res.error);
        state.searching = false;
        showScreen('setup');
      }
    });
  }

  // ----- Searching -----
  function renderSearching() {
    const s = el(`<div class="screen active"></div>`);
    const interestText = state.interests.length
      ? state.interests.slice(0, 5).join(', ') + (state.interests.length > 5 ? '…' : '')
      : 'Any interests';
    s.innerHTML = `
      <div class="searching-wrap">
        <div class="spinner"></div>
        <div class="search-title">Looking for someone...</div>
        <div class="search-sub">${escapeHtml(interestText)}</div>
        <button class="btn btn-ghost" id="cancelSearch" style="max-width:200px">Cancel</button>
      </div>
    `;
    s.querySelector('#cancelSearch').onclick = () => {
      state.socket?.emit('queue_leave');
      state.searching = false;
      showScreen('setup');
    };
    return s;
  }

  // ----- Chat (LIGHT THEME) -----
  function renderChat() {
    const s = el(`<div class="chat-screen active"></div>`);
    const partnerName = state.partner?.displayName || 'Stranger';
    s.innerHTML = `
      <div class="chat-header">
        <button class="back-btn" id="leaveChat" title="Leave">←</button>
        <div class="partner-info">
          <div class="partner-name">${escapeHtml(partnerName)}</div>
          <div class="partner-status" id="partnerStatus">Online</div>
        </div>
        <button class="icon-btn" id="reportBtn" title="Report">⚑</button>
        <button class="icon-btn" id="moreBtn" title="More">⋮</button>
      </div>
      <div class="chat-actions">
        <button id="nextBtn">Next</button>
        <button id="blockBtn" class="danger">Block</button>
        <button id="reportAction">Report</button>
      </div>
      <div class="messages" id="msgList"></div>
      <div class="typing-indicator" id="typingInd">typing…</div>
      <div class="composer">
        <button class="icon-btn" id="emojiBtn" title="Emoji">😊</button>
        <input type="text" id="msgInput" placeholder="Type a message..." maxlength="2000" autocomplete="off" />
        <button class="send-btn" id="sendBtn" disabled>➤</button>
      </div>
    `;

    const list = s.querySelector('#msgList');
    state.messages.forEach(m => list.appendChild(createMsgEl(m)));
    scrollMessages();

    const input = s.querySelector('#msgInput');
    const sendBtn = s.querySelector('#sendBtn');

    input.oninput = () => {
      sendBtn.disabled = !input.value.trim();
      if (input.value.trim()) {
        state.socket?.emit('typing_start');
      } else {
        state.socket?.emit('typing_stop');
      }
    };

    let typingTimer;
    input.onkeydown = (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
      clearTimeout(typingTimer);
      typingTimer = setTimeout(() => state.socket?.emit('typing_stop'), 1500);
    };

    sendBtn.onclick = sendMessage;

    function sendMessage() {
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      sendBtn.disabled = true;
      state.socket?.emit('typing_stop');
      state.socket?.emit('chat_message', { text }, (res) => {
        if (res?.error) toast(res.error);
      });
    }

    s.querySelector('#leaveChat').onclick = () => {
      state.socket?.emit('leave_chat');
      state.chat = null;
      state.partner = null;
      state.messages = [];
      showScreen('setup');
    };

    s.querySelector('#nextBtn').onclick = () => {
      state.socket?.emit('next_user', (res) => {
        if (res?.error) toast(res.error);
        else {
          state.chat = null;
          state.partner = null;
          state.messages = [];
          state.searching = true;
          showScreen('searching');
        }
      });
    };

    s.querySelector('#blockBtn').onclick = () => {
      if (!confirm('Block this user? You will leave the chat and they cannot match with you again.')) return;
      state.socket?.emit('block_user', {}, (res) => {
        toast('User blocked');
        state.chat = null;
        state.partner = null;
        state.messages = [];
        showScreen('setup');
      });
    };

    const openReport = () => openReportModal();
    s.querySelector('#reportBtn').onclick = openReport;
    s.querySelector('#reportAction').onclick = openReport;

    s.querySelector('#moreBtn').onclick = () => {
      // simple menu
      const choice = prompt('Options:\n1 = Clear chat locally\n2 = Report\n3 = Leave\n\nEnter number:');
      if (choice === '1') {
        state.messages = [];
        list.innerHTML = '';
        toast('Chat cleared locally');
      } else if (choice === '2') openReport();
      else if (choice === '3') s.querySelector('#leaveChat').click();
    };

    s.querySelector('#emojiBtn').onclick = () => {
      input.value += '😊';
      input.focus();
      sendBtn.disabled = false;
    };

    // Focus input on mobile after short delay
    setTimeout(() => input.focus(), 300);
    return s;
  }

  function createMsgEl(msg) {
    const mine = msg.from === state.user?.id;
    const d = document.createElement('div');
    d.className = 'msg ' + (mine ? 'mine' : 'theirs');
    const time = new Date(msg.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    d.innerHTML = `${escapeHtml(msg.text)}<div class="ts">${time}</div>`;
    return d;
  }

  function appendMessage(msg) {
    const list = document.getElementById('msgList');
    if (!list) return;
    list.appendChild(createMsgEl(msg));
  }

  function scrollMessages() {
    const list = document.getElementById('msgList');
    if (list) list.scrollTop = list.scrollHeight;
  }

  function openReportModal() {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay show';
    overlay.innerHTML = `
      <div class="modal">
        <h3>Report user</h3>
        <p style="font-size:14px;color:#aaa;margin-bottom:8px">Why are you reporting this user?</p>
        <div class="reason-list">
          <button data-r="harassment">Harassment / bullying</button>
          <button data-r="spam">Spam / advertising</button>
          <button data-r="inappropriate">Inappropriate content</button>
          <button data-r="underage">Suspected underage</button>
          <button data-r="other">Other</button>
        </div>
        <button class="btn btn-ghost" id="cancelReport" style="margin-top:8px">Cancel</button>
      </div>
    `;
    document.body.appendChild(overlay);
    overlay.querySelector('#cancelReport').onclick = () => overlay.remove();
    overlay.querySelectorAll('[data-r]').forEach(btn => {
      btn.onclick = () => {
        const reason = btn.dataset.r;
        state.socket?.emit('report_user', { reason }, (res) => {
          toast(res?.message || 'Report submitted');
          overlay.remove();
        });
      };
    });
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ========== INIT ==========
  connectSocket();
  // If already has session, skip to setup after quick register
  if (state.sessionToken && state.displayName) {
    registerUser((ok) => {
      showScreen(ok ? 'setup' : 'welcome');
    });
  } else {
    showScreen('welcome');
  }

  // Heartbeat
  setInterval(() => {
    if (state.socket?.connected) state.socket.emit('heartbeat');
  }, 25000);

})();
