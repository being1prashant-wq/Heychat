# PulseChat

A modern, mobile-first random 1-to-1 chat platform with real matchmaking, interests-based matching, real-time messaging, reporting, and safety features.

**Not affiliated with any existing chat service.** Built from scratch as a clean, original product.

## Features

- Pure black & white onboarding / setup experience
- Light-themed chat interface once matched
- Interest tags (optional) with preferential matching
- Real WebSocket matchmaking queue
- Next / Leave / Report / Block
- Anonymous sessions with optional persistence
- Rate limiting & basic anti-spam
- Admin overview endpoints
- Modular architecture ready for payments & full accounts

## Quick Start (Local)

```bash
cd random-chat
npm install
node server.js
```

Open **http://localhost:3000** in two different browser windows (or one normal + one incognito).

1. Complete onboarding in both windows (you can use different interests that overlap, e.g. both add "Music" and "Gaming").
2. On the **New Chat** screen press **Start Chat** in both windows.
3. They should match within a few seconds and the chat UI will open automatically.
4. Type messages — they appear in real time on the other side.
5. Use **Next** to re-enter the queue, **Report**, **Block**, or leave.

## How Matchmaking Works

1. User presses Start → `queue_join` event.
2. User is added to an in-memory match queue with their interests.
3. Server searches for the best candidate:
   - Prefers users who share the most interests.
   - After a short wait (or when queue is active) it broadens to any available user.
4. On match: both users are removed from the queue, a unique `chatId` is created, and both receive a `match_found` event.
5. Messages are exchanged only between the two sockets belonging to that chat.

Users never match with themselves. Blocked pairs are skipped. Stale queue entries are cleaned periodically.

## Environment Variables

Copy `.env.example` to `.env` and set:

| Variable | Purpose |
|----------|---------|
| `PORT` | Server port (default 3000) |
| `AUTH_SECRET` | JWT / session signing secret |
| `WEBSOCKET_SECRET` | Optional WS extra auth |
| `ADMIN_KEY` | Protects `/api/admin/*` routes |
| `PAYMENT_*` | Reserved for future payment provider |
| `MODERATION_API_KEY` | Reserved for external moderation |
| `DATABASE_URL` | For future Prisma/Postgres migration |

## Admin

```
GET /api/admin/overview?key=YOUR_ADMIN_KEY
POST /api/admin/ban  { "userId": "...", "reason": "...", "hours": 24 }
Header: x-admin-key: YOUR_ADMIN_KEY
```

## Production Notes

- Put the app behind HTTPS (Nginx / Caddy / Cloudflare).
- Use a process manager (`pm2`, `systemd`).
- For horizontal scale, replace the in-memory queue & maps with Redis (pub/sub + sorted sets for the match queue).
- Persist users, reports, blocks, and limited chat metadata in Postgres (schema outlined below).
- Configure payment webhooks only on the server; never trust the client for entitlement activation.
- Set strong random values for all secrets.
- Enable CORS only for your real domain.

## Suggested Database Schema (future)

```
users (id, display_name, interests jsonb, is_banned, ban_reason, report_count, created_at)
sessions (id, user_id, expires_at)
match_queue (user_id, interests, joined_at, socket_id)  -- or Redis
chat_sessions (id, user1_id, user2_id, started_at, ended_at)
messages (id, chat_id, from_id, text, created_at)       -- retain only what policy allows
blocks (user_id, blocked_user_id)
reports (id, reporter_id, reported_id, reason, status, created_at)
moderation_actions (id, user_id, action, reason, admin_id, created_at)
payments / entitlements  -- modular, ready when needed
```

## Testing Checklist

- [ ] Two browsers match when both press Start
- [ ] Overlapping interests preferred
- [ ] Messages deliver both ways
- [ ] Typing indicator appears
- [ ] Next returns both to queue (or leaves the other)
- [ ] Report creates an entry visible in admin overview
- [ ] Block prevents future matching
- [ ] Refresh / reconnect restores session where possible
- [ ] Mobile viewport feels native (full screen, large targets)

## License

MIT — free to use and modify. Do not copy proprietary assets or branding from any commercial random-chat product.
