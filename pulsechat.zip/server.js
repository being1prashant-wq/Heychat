require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  },
  pingTimeout: 60000,
  pingInterval: 25000
});

const PORT = process.env.PORT || 3000;
const AUTH_SECRET = process.env.AUTH_SECRET || 'pulsechat-dev-secret-change-in-production';
const WEBSOCKET_SECRET = process.env.WEBSOCKET_SECRET || 'ws-secret-change-me';

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ===================== IN-MEMORY + FILE PERSISTENCE =====================
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function loadJSON(name, fallback) {
  const file = path.join(DATA_DIR, name + '.json');
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {}
  return fallback;
}
function saveJSON(name, data) {
  const file = path.join(DATA_DIR, name + '.json');
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

let users = loadJSON('users', {});           // id -> user
let sessions = loadJSON('sessions', {});    // sessionId -> userId
let reports = loadJSON('reports', []);
let blocks = loadJSON('blocks', {});        // userId -> [blockedUserIds]
let friends = loadJSON('friends', {});      // userId -> [friendIds]
let moderationLogs = loadJSON('moderation', []);
let chatHistory = loadJSON('chat_history', {}); // sessionId -> messages (limited)

// Runtime state (not persisted fully for privacy)
const onlineUsers = new Map();      // socketId -> { userId, displayName, interests, gender, avatar, socketId, lastSeen }
const matchQueue = new Map();       // userId -> { userId, interests, socketId, joinedAt, preferences }
const activeChats = new Map();      // chatId -> { id, user1, user2, startedAt, messages: [] }
const userToChat = new Map();       // userId -> chatId
const socketToUser = new Map();     // socketId -> userId
const typingUsers = new Map();      // chatId -> Set of userIds

// Rate limiting
const rateLimits = new Map(); // key -> { count, resetAt }

function rateLimit(key, max = 20, windowMs = 60000) {
  const now = Date.now();
  let entry = rateLimits.get(key);
  if (!entry || now > entry.resetAt) {
    entry = { count: 0, resetAt: now + windowMs };
    rateLimits.set(key, entry);
  }
  entry.count++;
  return entry.count <= max;
}

// ===================== HELPERS =====================
function generateUserId() {
  return 'u_' + uuidv4().replace(/-/g, '').slice(0, 16);
}

function createAnonymousUser(displayName, interests = [], gender = 'prefer-not') {
  const id = generateUserId();
  const user = {
    id,
    displayName: (displayName || 'Anonymous').slice(0, 24).trim() || 'Anonymous',
    interests: Array.isArray(interests) ? interests.map(i => String(i).toLowerCase().trim()).filter(Boolean).slice(0, 20) : [],
    gender: gender || 'prefer-not',
    avatar: null,
    createdAt: new Date().toISOString(),
    isAnonymous: true,
    isBanned: false,
    banReason: null,
    banExpires: null,
    reportCount: 0
  };
  users[id] = user;
  saveJSON('users', users);
  return user;
}

function getUser(userId) {
  return users[userId] || null;
}

function isBlocked(userA, userB) {
  const aBlocks = blocks[userA] || [];
  const bBlocks = blocks[userB] || [];
  return aBlocks.includes(userB) || bBlocks.includes(userA);
}

function sanitizeMessage(text) {
  if (typeof text !== 'string') return '';
  return text.slice(0, 2000).replace(/</g, '&lt;').replace(/>/g, '&gt;').trim();
}

function interestOverlap(a, b) {
  if (!a || !b || !a.length || !b.length) return 0;
  const setB = new Set(b.map(i => i.toLowerCase()));
  return a.filter(i => setB.has(i.toLowerCase())).length;
}

// ===================== MATCHMAKING =====================
function findBestMatch(userId, interests, preferInterests = true) {
  let best = null;
  let bestScore = -1;
  const now = Date.now();

  for (const [qid, entry] of matchQueue) {
    if (qid === userId) continue;
    if (isBlocked(userId, qid)) continue;
    const otherUser = getUser(qid);
    if (!otherUser || otherUser.isBanned) continue;
    // Check if other is still online
    if (!onlineUsers.has(entry.socketId)) continue;

    let score = 0;
    if (preferInterests && interests.length && entry.interests.length) {
      score = interestOverlap(interests, entry.interests) * 10;
    }
    // Prefer longer waiting users slightly
    score += Math.min(5, (now - entry.joinedAt) / 10000);
    // Small random to break ties
    score += Math.random();

    if (score > bestScore) {
      bestScore = score;
      best = entry;
    }
  }
  return best;
}

function tryMatch(userId) {
  const entry = matchQueue.get(userId);
  if (!entry) return null;

  // First try with interest preference
  let match = findBestMatch(userId, entry.interests, true);
  // If no good overlap match and queue has people waiting > 8s, broaden
  if (!match) {
    const waitingLong = Array.from(matchQueue.values()).some(e => e.userId !== userId && Date.now() - e.joinedAt > 8000);
    if (waitingLong || matchQueue.size >= 2) {
      match = findBestMatch(userId, entry.interests, false);
    }
  }

  if (!match) return null;

  // Create chat
  const chatId = 'chat_' + uuidv4().replace(/-/g, '').slice(0, 12);
  const user1 = getUser(userId);
  const user2 = getUser(match.userId);

  const chat = {
    id: chatId,
    user1: { id: user1.id, displayName: user1.displayName, avatar: user1.avatar },
    user2: { id: user2.id, displayName: user2.displayName, avatar: user2.avatar },
    startedAt: new Date().toISOString(),
    messages: []
  };
  activeChats.set(chatId, chat);
  userToChat.set(userId, chatId);
  userToChat.set(match.userId, chatId);

  // Remove both from queue
  matchQueue.delete(userId);
  matchQueue.delete(match.userId);

  return { chat, matchSocketId: match.socketId, matchUserId: match.userId };
}

// ===================== SOCKET.IO =====================
io.use((socket, next) => {
  // Simple auth via handshake
  const token = socket.handshake.auth?.token || socket.handshake.query?.token;
  if (token) {
    try {
      const payload = jwt.verify(token, AUTH_SECRET);
      socket.userId = payload.userId;
      socket.isAdmin = payload.isAdmin || false;
    } catch (e) {}
  }
  next();
});

io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);

  socket.on('register', (data, cb) => {
    try {
      if (!rateLimit('reg:' + socket.handshake.address, 10, 60000)) {
        return cb?.({ error: 'Too many attempts' });
      }
      const { displayName, interests, gender, sessionToken } = data || {};
      let user;

      if (sessionToken && sessions[sessionToken]) {
        const uid = sessions[sessionToken];
        user = getUser(uid);
        if (user && user.isBanned) {
          return cb?.({ error: 'Account suspended' });
        }
      }

      if (!user) {
        user = createAnonymousUser(displayName, interests, gender);
        const sessionId = uuidv4();
        sessions[sessionId] = user.id;
        saveJSON('sessions', sessions);
        user.sessionToken = sessionId;
      } else {
        // Update profile
        if (displayName) user.displayName = displayName.slice(0, 24).trim() || user.displayName;
        if (Array.isArray(interests)) {
          user.interests = interests.map(i => String(i).toLowerCase().trim()).filter(Boolean).slice(0, 20);
        }
        if (gender) user.gender = gender;
        users[user.id] = user;
        saveJSON('users', users);
      }

      socket.userId = user.id;
      socketToUser.set(socket.id, user.id);

      onlineUsers.set(socket.id, {
        userId: user.id,
        displayName: user.displayName,
        interests: user.interests,
        gender: user.gender,
        avatar: user.avatar,
        socketId: socket.id,
        lastSeen: Date.now()
      });

      cb?.({
        success: true,
        user: {
          id: user.id,
          displayName: user.displayName,
          interests: user.interests,
          gender: user.gender,
          avatar: user.avatar,
          sessionToken: user.sessionToken || Object.keys(sessions).find(k => sessions[k] === user.id)
        }
      });
    } catch (err) {
      console.error('register error', err);
      cb?.({ error: 'Registration failed' });
    }
  });

  socket.on('update_profile', (data, cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not registered' });
    const user = getUser(userId);
    if (!user) return cb?.({ error: 'User not found' });

    if (data.displayName) user.displayName = String(data.displayName).slice(0, 24).trim() || user.displayName;
    if (Array.isArray(data.interests)) {
      user.interests = data.interests.map(i => String(i).toLowerCase().trim()).filter(Boolean).slice(0, 20);
    }
    if (data.gender) user.gender = data.gender;
    users[userId] = user;
    saveJSON('users', users);

    const online = onlineUsers.get(socket.id);
    if (online) {
      online.displayName = user.displayName;
      online.interests = user.interests;
      online.gender = user.gender;
    }
    cb?.({ success: true, user: { id: user.id, displayName: user.displayName, interests: user.interests, gender: user.gender } });
  });

  socket.on('queue_join', (data, cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not registered' });
    const user = getUser(userId);
    if (!user || user.isBanned) return cb?.({ error: 'Cannot join queue' });

    if (!rateLimit('queue:' + userId, 15, 60000)) {
      return cb?.({ error: 'Please wait before trying again' });
    }

    // Leave any existing chat
    const existingChatId = userToChat.get(userId);
    if (existingChatId) {
      leaveChat(userId, existingChatId, 'next');
    }

    // Prevent duplicate
    if (matchQueue.has(userId)) {
      matchQueue.delete(userId);
    }

    const interests = Array.isArray(data?.interests) ? data.interests : (user.interests || []);
    const preferInterests = data?.matchWithInterests !== false;

    matchQueue.set(userId, {
      userId,
      interests,
      socketId: socket.id,
      joinedAt: Date.now(),
      preferInterests
    });

    // Update online interests
    const online = onlineUsers.get(socket.id);
    if (online) online.interests = interests;

    cb?.({ success: true, status: 'searching' });

    // Try immediate match
    const result = tryMatch(userId);
    if (result) {
      notifyMatch(userId, result);
    } else {
      // Also try matching for others who might now match
      for (const [qid] of matchQueue) {
        if (qid === userId) continue;
        const r = tryMatch(qid);
        if (r) notifyMatch(qid, r);
      }
    }
  });

  socket.on('queue_leave', (cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (userId) matchQueue.delete(userId);
    cb?.({ success: true });
  });

  socket.on('chat_message', (data, cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not authenticated' });

    if (!rateLimit('msg:' + userId, 30, 10000)) {
      return cb?.({ error: 'Slow down' });
    }

    const chatId = userToChat.get(userId);
    if (!chatId) return cb?.({ error: 'Not in a chat' });
    const chat = activeChats.get(chatId);
    if (!chat) return cb?.({ error: 'Chat not found' });

    const text = sanitizeMessage(data?.text);
    if (!text) return cb?.({ error: 'Empty message' });

    const msg = {
      id: 'm_' + uuidv4().slice(0, 8),
      chatId,
      from: userId,
      text,
      ts: Date.now(),
      status: 'sent'
    };
    chat.messages.push(msg);
    // Keep only last 200 messages in memory
    if (chat.messages.length > 200) chat.messages = chat.messages.slice(-200);

    // Persist limited history
    if (!chatHistory[chatId]) chatHistory[chatId] = [];
    chatHistory[chatId].push({ from: userId, text, ts: msg.ts });
    if (chatHistory[chatId].length > 100) chatHistory[chatId] = chatHistory[chatId].slice(-100);
    saveJSON('chat_history', chatHistory);

    // Emit to both participants
    const otherId = chat.user1.id === userId ? chat.user2.id : chat.user1.id;
    const otherSocketId = findSocketForUser(otherId);

    socket.emit('chat_message', msg);
    if (otherSocketId) {
      io.to(otherSocketId).emit('chat_message', msg);
    }
    cb?.({ success: true, message: msg });
  });

  socket.on('typing_start', () => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return;
    const chatId = userToChat.get(userId);
    if (!chatId) return;
    if (!typingUsers.has(chatId)) typingUsers.set(chatId, new Set());
    typingUsers.get(chatId).add(userId);

    const chat = activeChats.get(chatId);
    if (!chat) return;
    const otherId = chat.user1.id === userId ? chat.user2.id : chat.user1.id;
    const otherSocket = findSocketForUser(otherId);
    if (otherSocket) io.to(otherSocket).emit('typing_start', { userId });
  });

  socket.on('typing_stop', () => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return;
    const chatId = userToChat.get(userId);
    if (!chatId) return;
    if (typingUsers.has(chatId)) typingUsers.get(chatId).delete(userId);

    const chat = activeChats.get(chatId);
    if (!chat) return;
    const otherId = chat.user1.id === userId ? chat.user2.id : chat.user1.id;
    const otherSocket = findSocketForUser(otherId);
    if (otherSocket) io.to(otherSocket).emit('typing_stop', { userId });
  });

  socket.on('next_user', (cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not authenticated' });
    const chatId = userToChat.get(userId);
    if (chatId) {
      leaveChat(userId, chatId, 'next');
    }
    // Auto re-join queue with previous interests
    const online = onlineUsers.get(socket.id);
    const interests = online?.interests || getUser(userId)?.interests || [];
    matchQueue.set(userId, {
      userId,
      interests,
      socketId: socket.id,
      joinedAt: Date.now(),
      preferInterests: true
    });
    cb?.({ success: true, status: 'searching' });

    const result = tryMatch(userId);
    if (result) notifyMatch(userId, result);
  });

  socket.on('leave_chat', (cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not authenticated' });
    const chatId = userToChat.get(userId);
    if (chatId) leaveChat(userId, chatId, 'leave');
    matchQueue.delete(userId);
    cb?.({ success: true });
  });

  socket.on('report_user', (data, cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not authenticated' });
    if (!rateLimit('report:' + userId, 5, 300000)) {
      return cb?.({ error: 'Too many reports' });
    }

    const { reason, details, reportedUserId } = data || {};
    let targetId = reportedUserId;
    if (!targetId) {
      const chatId = userToChat.get(userId);
      if (chatId) {
        const chat = activeChats.get(chatId);
        if (chat) targetId = chat.user1.id === userId ? chat.user2.id : chat.user1.id;
      }
    }
    if (!targetId) return cb?.({ error: 'No user to report' });

    const report = {
      id: 'r_' + uuidv4().slice(0, 10),
      reporterId: userId,
      reportedId: targetId,
      reason: String(reason || 'other').slice(0, 50),
      details: String(details || '').slice(0, 500),
      chatId: userToChat.get(userId) || null,
      createdAt: new Date().toISOString(),
      status: 'open'
    };
    reports.push(report);
    saveJSON('reports', reports);

    const reported = getUser(targetId);
    if (reported) {
      reported.reportCount = (reported.reportCount || 0) + 1;
      users[targetId] = reported;
      saveJSON('users', users);
      // Auto suspend after many reports
      if (reported.reportCount >= 8) {
        reported.isBanned = true;
        reported.banReason = 'Multiple reports';
        reported.banExpires = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();
        moderationLogs.push({
          action: 'auto_ban',
          userId: targetId,
          reason: 'report threshold',
          at: new Date().toISOString()
        });
        saveJSON('moderation', moderationLogs);
        saveJSON('users', users);
      }
    }

    cb?.({ success: true, message: 'Report submitted. Thank you.' });
  });

  socket.on('block_user', (data, cb) => {
    const userId = socket.userId || socketToUser.get(socket.id);
    if (!userId) return cb?.({ error: 'Not authenticated' });

    let targetId = data?.userId;
    if (!targetId) {
      const chatId = userToChat.get(userId);
      if (chatId) {
        const chat = activeChats.get(chatId);
        if (chat) targetId = chat.user1.id === userId ? chat.user2.id : chat.user1.id;
      }
    }
    if (!targetId || targetId === userId) return cb?.({ error: 'Invalid target' });

    if (!blocks[userId]) blocks[userId] = [];
    if (!blocks[userId].includes(targetId)) {
      blocks[userId].push(targetId);
      saveJSON('blocks', blocks);
    }

    // Leave chat if active
    const chatId = userToChat.get(userId);
    if (chatId) leaveChat(userId, chatId, 'block');

    cb?.({ success: true });
  });

  socket.on('friend_request', (data, cb) => {
    // Optional feature stub
    cb?.({ success: true, message: 'Friend requests coming soon' });
  });

  socket.on('disconnect', (reason) => {
    console.log('Socket disconnected:', socket.id, reason);
    const userId = socketToUser.get(socket.id) || socket.userId;
    if (userId) {
      matchQueue.delete(userId);
      const chatId = userToChat.get(userId);
      if (chatId) {
        leaveChat(userId, chatId, 'disconnect');
      }
    }
    onlineUsers.delete(socket.id);
    socketToUser.delete(socket.id);
  });

  // Heartbeat presence
  socket.on('heartbeat', () => {
    const online = onlineUsers.get(socket.id);
    if (online) online.lastSeen = Date.now();
  });
});

function findSocketForUser(userId) {
  for (const [sid, info] of onlineUsers) {
    if (info.userId === userId) return sid;
  }
  return null;
}

function notifyMatch(userId, result) {
  const { chat, matchSocketId, matchUserId } = result;
  const userSocket = findSocketForUser(userId);

  const payloadForUser = {
    chatId: chat.id,
    partner: chat.user1.id === userId ? chat.user2 : chat.user1,
    startedAt: chat.startedAt
  };
  const payloadForMatch = {
    chatId: chat.id,
    partner: chat.user2.id === matchUserId ? chat.user1 : chat.user2,
    startedAt: chat.startedAt
  };

  if (userSocket) {
    io.to(userSocket).emit('match_found', payloadForUser);
  }
  if (matchSocketId) {
    io.to(matchSocketId).emit('match_found', payloadForMatch);
  }
  console.log(`Match created: ${userId} <-> ${matchUserId} chat=${chat.id}`);
}

function leaveChat(userId, chatId, reason = 'leave') {
  const chat = activeChats.get(chatId);
  if (!chat) {
    userToChat.delete(userId);
    return;
  }

  const otherId = chat.user1.id === userId ? chat.user2.id : chat.user1.id;
  userToChat.delete(userId);
  userToChat.delete(otherId);

  const otherSocket = findSocketForUser(otherId);
  if (otherSocket) {
    io.to(otherSocket).emit('chat_end', { reason, chatId });
  }

  // Soft delete chat after short delay to allow final events
  setTimeout(() => {
    activeChats.delete(chatId);
    typingUsers.delete(chatId);
  }, 2000);
}

// ===================== REST API =====================
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    online: onlineUsers.size,
    queue: matchQueue.size,
    activeChats: activeChats.size,
    time: new Date().toISOString()
  });
});

app.get('/api/stats', (req, res) => {
  res.json({
    onlineUsers: onlineUsers.size,
    searching: matchQueue.size,
    activeChats: activeChats.size,
    totalUsers: Object.keys(users).length,
    openReports: reports.filter(r => r.status === 'open').length
  });
});

// Admin simple endpoints (protect with secret in prod)
app.get('/api/admin/overview', (req, res) => {
  const key = req.headers['x-admin-key'] || req.query.key;
  if (key !== (process.env.ADMIN_KEY || 'admin-dev-key')) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  res.json({
    online: Array.from(onlineUsers.values()).map(u => ({
      id: u.userId,
      name: u.displayName,
      interests: u.interests
    })),
    queue: Array.from(matchQueue.values()).map(q => ({
      id: q.userId,
      interests: q.interests,
      waitingSec: Math.round((Date.now() - q.joinedAt) / 1000)
    })),
    chats: Array.from(activeChats.values()).map(c => ({
      id: c.id,
      users: [c.user1.displayName, c.user2.displayName],
      messages: c.messages.length
    })),
    reports: reports.slice(-50),
    banned: Object.values(users).filter(u => u.isBanned).map(u => ({ id: u.id, name: u.displayName, reason: u.banReason }))
  });
});

app.post('/api/admin/ban', (req, res) => {
  const key = req.headers['x-admin-key'] || req.query.key;
  if (key !== (process.env.ADMIN_KEY || 'admin-dev-key')) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const { userId, reason, hours } = req.body || {};
  const user = getUser(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  user.isBanned = true;
  user.banReason = reason || 'Admin action';
  user.banExpires = hours ? new Date(Date.now() + hours * 3600 * 1000).toISOString() : null;
  users[userId] = user;
  saveJSON('users', users);
  moderationLogs.push({ action: 'ban', userId, reason, at: new Date().toISOString() });
  saveJSON('moderation', moderationLogs);
  // Kick from queue/chat
  matchQueue.delete(userId);
  const chatId = userToChat.get(userId);
  if (chatId) leaveChat(userId, chatId, 'banned');
  res.json({ success: true });
});

// Fallback to SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Cleanup stale queue entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [uid, entry] of matchQueue) {
    if (!onlineUsers.has(entry.socketId) || now - entry.joinedAt > 10 * 60 * 1000) {
      matchQueue.delete(uid);
    }
  }
  // Clean old rate limits
  for (const [k, v] of rateLimits) {
    if (now > v.resetAt) rateLimits.delete(k);
  }
}, 30000);

server.listen(PORT, "0.0.0.0", () => {
  console.log(`PulseChat server running on http://localhost:${PORT}`);
  console.log(`Open two browser tabs to test matchmaking.`);
});
